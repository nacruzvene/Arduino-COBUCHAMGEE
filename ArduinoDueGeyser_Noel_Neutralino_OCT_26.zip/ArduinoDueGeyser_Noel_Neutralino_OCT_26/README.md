Arduino DUE code for the geyser operation. I hope it is nicely commented. Just do make and then make upload
